import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ScrollService } from '../shared/services/scroll.service';

@Component({
  selector: 'app-teste',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './teste.component.html',
  styleUrl: './teste.component.scss'
})
export class TesteComponent {
  devoExibirTitulo: boolean = true;
  numeros = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  botaoAtivo: boolean = false;
  itens = [
    {name: 'item1', visible: true},
    {name: 'item2', visible: false},
    {name: 'item3', visible: true},
    {name: 'item4', visible: false}
  ];

  constructor(private scrollService: ScrollService) {
  }

  scrollToTop(id: string) {
    this.scrollService.scroll(id);
  }
}
