export interface Carnes {
    id: string;
    nome: string;
    tipo: string;
    preco_kg: number;
    consumo_medio_adulto_g: number;
    consumo_medio_crianca_g: number;
}