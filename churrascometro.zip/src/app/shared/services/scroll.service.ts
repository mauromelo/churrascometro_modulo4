import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ScrollService {

  constructor() { }

  scroll(id: string) {
    const div = document.getElementById(id);

    if(div) {
      div.scrollIntoView({ behavior:'smooth' });
    }
  }
}
